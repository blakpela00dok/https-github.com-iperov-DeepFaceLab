from models import ModelBase
from models import TrainingDataType
import numpy as np
import cv2

from nnlib import DSSIMMaskLossClass
from nnlib import conv
from nnlib import upscale
from nnlib import resize_like
from nnlib import total_variation_loss
from nnlib import tf_dssim
from facelib import FaceType

class Model(ModelBase):

    generatorH5 = 'generator.h5'
    cdcoreH5 = 'cdcore.h5'
    discriminatorH5 = 'discriminator.h5'
    classifierH5 = 'classifier.h5'
    
    aueH5 = 'aue.h5'
    aud_srcH5 = 'aud_src.h5'
    aud_dstH5 = 'aud_dst.h5'

    #override
    def onInitialize(self, batch_size=-1, **in_options):
        tf = self.tf
        keras = self.keras
        K = keras.backend
        
        #if self.gpu_total_vram_gb < 4:
        #    raise Exception ('Sorry, this model works only on 4GB+ GPU')
        
        self.batch_size = batch_size
        if self.batch_size == 0:          
            if self.gpu_total_vram_gb == 4:
                self.batch_size = 2
            elif self.gpu_total_vram_gb == 5:
                self.batch_size = 4
            elif self.gpu_total_vram_gb == 6:
                self.batch_size = 8
            else: 
                self.batch_size = 16
    
        
        
        #self.train_au = True
        self.train_au = False
        
        if self.train_au:
            self.batch_size = 8
        else:
            self.batch_size = 16

        img_shape = (128, 128, 3)
        img_mask_shape = (128, 128, 1)
        au_shape = (64,)
        img_input = self.keras.layers.Input(img_shape)
        
        self.aue = self.AUEncoder(img_input)
        self.aud_src = self.AUDecoder()
        self.aud_dst = self.AUDecoder()
        
        #
        #
        self.generator = self.Generator(img_input, keras.layers.Input(au_shape) )
        self.cdcore = self.CDCore(img_input)
        self.discriminator = self.CDOutput()
        self.classifier = self.CDOutput()
        
        if (not self.train_au) or (self.train_au and not self.is_first_run()):
            self.aue.load_weights (self.get_strpath_storage_for_file(self.aueH5))
            self.aud_src.load_weights (self.get_strpath_storage_for_file(self.aud_srcH5))
            self.aud_dst.load_weights (self.get_strpath_storage_for_file(self.aud_dstH5))
        
        if not self.train_au:
            if not self.is_first_run():           
                self.generator.load_weights  (self.get_strpath_storage_for_file(self.generatorH5))
                self.cdcore.load_weights  (self.get_strpath_storage_for_file(self.cdcoreH5))
                self.discriminator.load_weights  (self.get_strpath_storage_for_file(self.discriminatorH5))
                self.classifier.load_weights  (self.get_strpath_storage_for_file(self.classifierH5))

        optimizer = self.keras.optimizers.Adam(lr=1e-4, beta_1=0.9, beta_2=0.999)
        
        au_input_src_warped = self.keras.layers.Input(img_shape)
        au_input_src_target = self.keras.layers.Input(img_shape)
        au_input_src_target_mask = self.keras.layers.Input(img_mask_shape)
        au_input_dst_warped = self.keras.layers.Input(img_shape)
        au_input_dst_target = self.keras.layers.Input(img_shape)
        au_input_dst_target_mask = self.keras.layers.Input(img_mask_shape)
        
        au_src_code = self.aue(au_input_src_warped)
        au_dst_code = self.aue(au_input_dst_warped)
        
        au_rec_src = self.aud_src(au_src_code)
        au_rec_dst = self.aud_dst(au_dst_code)
        
        aued_loss = tf_dssim(tf, (au_input_src_target/2+0.5)*(au_input_src_target_mask/2+0.5), (au_rec_src/2+0.5)*(au_input_src_target_mask/2+0.5)) + \
                    tf_dssim(tf, (au_input_dst_target/2+0.5)*(au_input_dst_target_mask/2+0.5), (au_rec_dst/2+0.5)*(au_input_dst_target_mask/2+0.5))
  
        self.aued_train = K.function ([au_input_src_warped, au_input_src_target, au_input_src_target_mask, au_input_dst_warped, au_input_dst_target, au_input_dst_target_mask],[aued_loss],
                                       self.keras.optimizers.Adam(lr=5e-5, beta_1=0.5, beta_2=0.999).get_updates(aued_loss, self.aue.trainable_weights + self.aud_src.trainable_weights + self.aud_dst.trainable_weights)
                                     )
        self.aued_view = K.function ([au_input_src_warped,  au_input_dst_warped], [au_rec_src, au_rec_dst])
        self.aued_conv = K.function ([au_input_dst_warped], [au_rec_dst])
        
        
        x_real = self.keras.layers.Input(img_shape)
        x_wrpd = self.keras.layers.Input(img_shape)
        y_tgt = self.keras.layers.Input(img_shape)

        au_y_tgt = self.aue(y_tgt)        
        x_tgt = self.generator([x_wrpd, au_y_tgt])        
        au_x_tgt = self.aue(x_tgt)
        
        x_real_c = self.classifier(self.cdcore(x_real))
        x_tgt_c = self.classifier(self.cdcore(x_tgt))
        
        x_real_d = self.discriminator(self.cdcore(x_real))
        x_tgt_d = self.discriminator(self.cdcore(x_tgt))

        d_loss_common = K.mean( K.square(1.0-x_real_d) + K.square(x_tgt_d) )
        d_loss_src = d_loss_common + K.mean( K.square(0.0 - x_real_c) )        
        d_loss_dst = d_loss_common + K.mean( K.square(1.0 - x_real_c) )
                    
        self.d_src_train = K.function ([x_real, x_wrpd, y_tgt],[d_loss_src],        
                            self.keras.optimizers.Adam(lr=1e-4, beta_1=0.9, beta_2=0.999).get_updates(d_loss_src, self.cdcore.trainable_weights+self.discriminator.trainable_weights+self.classifier.trainable_weights)
                                 )
        
        self.d_dst_train = K.function ([x_real, x_wrpd, y_tgt],[d_loss_dst],        
                            self.keras.optimizers.Adam(lr=1e-4, beta_1=0.9, beta_2=0.999).get_updates(d_loss_dst, self.cdcore.trainable_weights+self.discriminator.trainable_weights+self.classifier.trainable_weights)
                                 )
  
        g_loss_common = K.mean(K.square(au_y_tgt - au_x_tgt)) + \
                        K.mean(K.abs(x_wrpd - x_tgt)) + \
                        total_variation_loss(keras, x_tgt) + \
                        1*K.mean(K.square(1.0-x_tgt_d))
                        
        g_loss_src = g_loss_common + 1*K.mean(K.square(0.0-x_tgt_c))
        g_loss_dst = g_loss_common + 1*K.mean(K.square(1.0-x_tgt_c))
  
        self.g_src_train = K.function ([x_real, x_wrpd, y_tgt],[g_loss_src],        
                            self.keras.optimizers.Adam(lr=1e-4, beta_1=0.9, beta_2=0.999).get_updates(g_loss_src, self.generator.trainable_weights)
                                 )
        
        self.g_dst_train = K.function ([x_real, x_wrpd, y_tgt],[g_loss_dst],        
                            self.keras.optimizers.Adam(lr=1e-4, beta_1=0.9, beta_2=0.999).get_updates(g_loss_dst, self.generator.trainable_weights)
                                 )
                                 
        self.g_view = K.function ([x_wrpd, y_tgt],[x_tgt])
        
        if self.is_training_mode:
            if self.train_au:
                self.aue, self.aud_src, self.aud_dst = self.to_multi_gpu_model_if_possible ( [self.aue, self.aud_src, self.aud_dst] )
            else:
                self.generator, self.cdcore, self.discriminator, self.classifier = self.to_multi_gpu_model_if_possible ( [self.generator, self.cdcore, self.discriminator, self.classifier] )
        
            from models import TrainingDataGenerator
            f = TrainingDataGenerator.SampleTypeFlags
            
            if self.train_au:
                self.set_training_data_generators ([            
                        TrainingDataGenerator(TrainingDataType.FACE, self.training_data_src_path, normalize_tanh=True, debug=self.is_debug(), batch_size=self.batch_size, output_sample_types=[ [f.TRANSFORMED | f.FULL_FACE | f.MODE_BGR, 128], [f.TRANSFORMED | f.FULL_FACE | f.MODE_BGR, 128], [f.TRANSFORMED | f.FULL_FACE | f.MASK_FULL | f.MODE_M, 128] ], random_flip=True ),
                        TrainingDataGenerator(TrainingDataType.FACE, self.training_data_dst_path, normalize_tanh=True, debug=self.is_debug(), batch_size=self.batch_size, output_sample_types=[ [f.TRANSFORMED | f.FULL_FACE | f.MODE_BGR, 128], [f.TRANSFORMED | f.FULL_FACE | f.MODE_BGR, 128], [f.TRANSFORMED | f.FULL_FACE | f.MASK_FULL | f.MODE_M, 128] ], random_flip=True ),
                        ])
            else:
                self.set_training_data_generators ([            
                        TrainingDataGenerator(TrainingDataType.FACE, self.training_data_src_path, normalize_tanh=True, debug=self.is_debug(), batch_size=self.batch_size, output_sample_types=[ [f.SOURCE | f.FULL_FACE | f.MODE_BGR, 128] ] ),
                        TrainingDataGenerator(TrainingDataType.FACE, self.training_data_src_path, normalize_tanh=True, debug=self.is_debug(), batch_size=self.batch_size, output_sample_types=[ [f.SOURCE | f.FULL_FACE | f.MODE_BGR, 128] ] ),
                        TrainingDataGenerator(TrainingDataType.FACE, self.training_data_dst_path, normalize_tanh=True, debug=self.is_debug(), batch_size=self.batch_size, output_sample_types=[ [f.SOURCE | f.FULL_FACE | f.MODE_BGR, 128] ] ),
                        TrainingDataGenerator(TrainingDataType.FACE, self.training_data_dst_path, normalize_tanh=True, debug=self.is_debug(), batch_size=self.batch_size, output_sample_types=[ [f.SOURCE | f.FULL_FACE | f.MODE_BGR, 128] ] ),
                        ])
                
        self.supress_std_once = False
        
    #override
    def onSave(self):        
        if self.train_au:
            self.save_weights_safe( [[self.aue, self.get_strpath_storage_for_file(self.aueH5)],
                                     [self.aud_src, self.get_strpath_storage_for_file(self.aud_srcH5)],
                                     [self.aud_dst, self.get_strpath_storage_for_file(self.aud_dstH5)],
                                    ] )
        else:
            self.save_weights_safe( [[self.generator, self.get_strpath_storage_for_file(self.generatorH5)],                                 
                                     [self.cdcore, self.get_strpath_storage_for_file(self.cdcoreH5)],
                                     [self.discriminator, self.get_strpath_storage_for_file(self.discriminatorH5)],
                                     [self.classifier, self.get_strpath_storage_for_file(self.classifierH5)],
                                    ] )
        
    #override
    def onTrainOneEpoch(self, sample):
        #warped_src, src_224, target_src_mask, target_src = sample[0]
        #warped_dst, dst_224, target_dst_mask, target_dst = sample[1]    
    
        if self.train_au:   
            src_warped, src_target, src_target_mask = sample[0]
            dst_warped, dst_target, dst_target_mask = sample[1]
            
         
            au_rec_loss = self.aued_train([src_warped, src_target, src_target_mask, dst_warped, dst_target, dst_target_mask])[0].mean()
            return ( ('au_rec', au_rec_loss), )
        else:
            src_source, = sample[0]
            src_source2, = sample[1]
            dst_source, = sample[2]
            dst_source2, = sample[3]
            
            d_loss_src = self.d_src_train ([src_source, src_source2, dst_source])[0]
            d_loss_dst = self.d_dst_train ([dst_source, dst_source2, src_source])[0]
            
            g_loss_src = self.g_src_train ([src_source, src_source2, dst_source])[0]
            g_loss_dst = self.g_dst_train ([dst_source, dst_source2, src_source])[0]
  
            return ( ('D_src',d_loss_src), ('D_dst',d_loss_dst),('G_src', g_loss_src), ('G_dst', g_loss_dst ) )

    #override
    def onGetPreview(self, sample):
        if self.train_au:
            test_A   = sample[0][1][0:4] #first 4 samples
            test_B   = sample[1][1][0:4] #first 4 samples
            
            AA, BB = self.aued_view ([test_A, test_B])
            AB, BA = self.aued_view ([test_B, test_A])
            
            
            test_A, test_B, AA, BB, AB, BA = [ np.clip(x / 2 + 0.5, 0.0, 1.0) for x in [test_A, test_B, AA, BB, AB, BA] ]

            
            st = []
            for i in range(0, len(test_A)):
                st.append ( np.concatenate ( (
                    test_A[i],
                    AA[i],
                    BA[i],
                    test_B[i],                
                    BB[i],
                    AB[i],                
                    ), axis=1) )
            return [ ('src, dst, src->dst', np.concatenate ( st, axis=0 ) ) ]
        else:
            src1   = sample[0][0][0:4] #first 4 samples
            src2   = sample[1][0][0:4] #first 4 samples
            dst1   = sample[2][0][0:4] #first 4 samples
            dst2   = sample[3][0][0:4] #first 4 samples
        
            sd = self.g_view ([src1,dst1])[0]
            ds = self.g_view ([dst1,src1])[0]
            
            
            src1, dst1, sd, ds  = [ np.clip(x / 2 + 0.5, 0.0, 1.0) for x in [src1, dst1, sd, ds] ]
            
            st = []
            for i in range(0, len(src1)):
                st.append ( np.concatenate ( (
                    src1[i],
                    dst1[i],
                    sd[i],
                    ds[i],           
                    ), axis=1) )
            return [ ('src, dst, src->dst, dst->src', np.concatenate ( st, axis=0 ) ) ]
    
    def predictor_func (self, face):
        
        x, = self.aued_conv ([ np.expand_dims(face * 2-1,0) ])
        
        return x[0] / 2 + 0.5
        
    #override
    def get_converter(self, **in_options):
        from models import ConverterAvatar

        return ConverterAvatar.ConverterAvatar(self.predictor_func, predictor_input_size=128, output_size=128, **in_options)
        
    def CDCore(self, input_layer):
        x = input_layer
        
        x = self.keras.layers.convolutional.Conv2D(32, kernel_size=5, strides=2, padding='same')(x)
        x = self.keras.layers.BatchNormalization()(x)
        x = self.keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        
        x = self.keras.layers.convolutional.Conv2D(64, kernel_size=5, strides=2, padding='same')(x)
        x = self.keras.layers.BatchNormalization()(x)
        x = self.keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        
        x = self.keras.layers.convolutional.Conv2D(128, kernel_size=5, strides=2, padding='same')(x)
        x = self.keras.layers.BatchNormalization()(x)
        x = self.keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        
        x = self.keras.layers.convolutional.Conv2D(256, kernel_size=3, strides=2, padding='same')(x)
        x = self.keras.layers.BatchNormalization()(x)
        x = self.keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        
        x = self.keras.layers.convolutional.Conv2D(512, kernel_size=3, strides=2, padding='same')(x)
        x = self.keras.layers.BatchNormalization()(x)
        x = self.keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        
        x = self.keras.layers.Dense(1024)(x)
        x = self.keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        
        return self.keras.models.Model (input_layer, x)
       
    def CDOutput(self):
        input_layer = self.keras.layers.Input ( shape=(1024, ) )
        x = input_layer
        x = self.keras.layers.Dense(2232)(x)
        return self.keras.models.Model (input_layer, x)
        
    def Generator(self, input_layer, input_au_code):
        x = input_layer #128,128,3
        
        x = self.keras.layers.convolutional.Conv2D(90, kernel_size=7, strides=1, padding='same')(x)
        x = self.keras.layers.BatchNormalization()(x)
        x = self.keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        
        x = self.keras.layers.convolutional.Conv2D(180, kernel_size=5, strides=2, padding='same')(x)
        x = self.keras.layers.BatchNormalization()(x)
        x = self.keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        
        x = self.keras.layers.convolutional.Conv2D(360, kernel_size=5, strides=2, padding='same')(x)
        x = self.keras.layers.BatchNormalization()(x)
        x = self.keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        
        x = self.keras.layers.convolutional.Conv2D(360, kernel_size=3, strides=1, padding='same')(x)
        x = self.keras.layers.BatchNormalization()(x)
        x = self.keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        
        ex = x
        #32,32, 256
        
        au_code = input_au_code
        au_code = self.keras.layers.RepeatVector( ex.shape[1].value*ex.shape[2].value ) (au_code)
        au_code = self.keras.layers.Reshape    ( (ex.shape[1].value,ex.shape[2].value,au_code.shape[-1].value) ) (au_code)
        
        x = self.keras.layers.Concatenate()( [x,au_code] )
        #32,32 360+64

        x = self.keras.layers.convolutional.Conv2D(360, kernel_size=3, strides=1, padding='same')(x)
        x = self.keras.layers.BatchNormalization()(x)
        x = self.keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        
        #32, 32, 256
        # decoder
        
        for _ in range (6):
            rx = x
            x = self.keras.layers.convolutional.Conv2D(360, kernel_size=3, strides=1, padding='same')(x)
            x = self.keras.layers.BatchNormalization()(x)
            x = self.keras.layers.advanced_activations.LeakyReLU(0.1)(x)
            x = self.keras.layers.convolutional.Conv2D(360, kernel_size=3, strides=1, padding='same')(x)
            x = self.keras.layers.BatchNormalization()(x)
            x = self.keras.layers.Add()([x, rx])
        
        x = self.keras.layers.Add()([x, ex])
        
        x = self.keras.layers.Conv2DTranspose(180, kernel_size=5, strides=2, padding='same')(x)
        x = self.keras.layers.BatchNormalization()(x)
        x = self.keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        
        x = self.keras.layers.Conv2DTranspose(90, kernel_size=5, strides=2, padding='same')(x)
        x = self.keras.layers.BatchNormalization()(x)
        x = self.keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        
        x = self.keras.layers.convolutional.Conv2D(3, kernel_size=5, strides=1, padding='same', activation='tanh')(x)
        
        return self.keras.models.Model ([input_layer,input_au_code], x)

    def AUEncoder(self, input_layer):
        x = input_layer
        x = self.keras.layers.convolutional.Conv2D(90, kernel_size=5, strides=1, padding='same')(x)
        x = self.keras.layers.convolutional.Conv2D(90, kernel_size=5, strides=1, padding='same')(x)
        x = self.keras.layers.MaxPooling2D(pool_size=(3, 3), strides=2, padding='same')(x)
        
        x = self.keras.layers.convolutional.Conv2D(180, kernel_size=3, strides=1, padding='same')(x)
        x = self.keras.layers.convolutional.Conv2D(180, kernel_size=3, strides=1, padding='same')(x)
        x = self.keras.layers.MaxPooling2D(pool_size=(3, 3), strides=2, padding='same')(x)
        
        x = self.keras.layers.convolutional.Conv2D(360, kernel_size=3, strides=1, padding='same')(x)
        x = self.keras.layers.convolutional.Conv2D(360, kernel_size=3, strides=1, padding='same')(x)
        x = self.keras.layers.MaxPooling2D(pool_size=(3, 3), strides=2, padding='same')(x)
        
        x = self.keras.layers.Dense (1024)(x)
        x = self.keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        x = self.keras.layers.Dropout(0.5)(x)
        
        x = self.keras.layers.Dense (1024)(x)
        x = self.keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        x = self.keras.layers.Dropout(0.5)(x)
        x = self.keras.layers.Flatten()(x)
        x = self.keras.layers.Dense (64)(x)
        
        return self.keras.models.Model (input_layer, x)
        
    def AUDecoder(self): 
        input_ = self.keras.layers.Input(shape=(64,))
        
        x = input_
        x = self.keras.layers.Dense (16*16*1024)(x)
        x = self.keras.layers.Reshape ( (16,16,1024) )(x)
        x = upscale(self.keras, x, 720)
        x = upscale(self.keras, x, 360)
        x = upscale(self.keras, x, 180)
        x = self.keras.layers.convolutional.Conv2D(3, kernel_size=5, padding='same', activation='tanh')(x)

        return self.keras.models.Model(input_, x)


from models import ModelBase
from models import TrainingDataType
import numpy as np

from nnlib import DSSIMMaskLossClass
from nnlib import conv
from nnlib import upscale
from facelib import FaceType

class Model(ModelBase):

    encoderH5 = 'encoder.h5'
    decoder_srcH5 = 'decoder_src.h5'
    decoder_dstH5 = 'decoder_dst.h5'

    #override
    def onInitialize(self, **in_options):
        tf = self.tf
        keras = self.keras
        K = keras.backend
        self.set_vram_batch_requirements( {1.5:2,2:2,3:8,4:16,5:24,6:32,7:40,8:48} )

        bgr_shape, mask_shape, self.encoder, self.decoder_src, self.decoder_dst = self.Build(self.created_vram_gb)
        if not self.is_first_run():
            self.encoder.load_weights     (self.get_strpath_storage_for_file(self.encoderH5))
            self.decoder_src.load_weights (self.get_strpath_storage_for_file(self.decoder_srcH5))
            self.decoder_dst.load_weights (self.get_strpath_storage_for_file(self.decoder_dstH5))
            
        input_src_bgr = self.keras.layers.Input(bgr_shape)
        input_src_mask = self.keras.layers.Input(mask_shape)
        input_dst_bgr = self.keras.layers.Input(bgr_shape)
        input_dst_mask = self.keras.layers.Input(mask_shape)

        rec_src_bgr, rec_src_mask = self.decoder_src( self.encoder(input_src_bgr) )        
        rec_dst_bgr, rec_dst_mask = self.decoder_dst( self.encoder(input_dst_bgr) )

        self.ae = self.keras.models.Model([input_src_bgr,input_src_mask,input_dst_bgr,input_dst_mask], [rec_src_bgr, rec_src_mask, rec_dst_bgr, rec_dst_mask] )
            
        if self.is_training_mode:
            self.ae, = self.to_multi_gpu_model_if_possible ( [self.ae,] )

        self.ae.compile(optimizer=self.keras.optimizers.Adam(lr=5e-5, beta_1=0.5, beta_2=0.999),
                        loss=[ DSSIMMaskLossClass(self.tf)([input_src_mask]), 'mse', DSSIMMaskLossClass(self.tf)([input_dst_mask]), 'mse' ] )
  
        self.src_view = K.function([input_src_bgr],[rec_src_bgr, rec_src_mask])
        self.dst_view = K.function([input_dst_bgr],[rec_dst_bgr, rec_dst_mask])
  
        if self.is_training_mode:
            from models import TrainingDataGenerator
            f = TrainingDataGenerator.SampleTypeFlags 
            self.set_training_data_generators ([    
                    TrainingDataGenerator(TrainingDataType.FACE, self.training_data_src_path, debug=self.is_debug(), batch_size=self.batch_size, output_sample_types=[ [f.WARPED_TRANSFORMED | f.FULL_FACE | f.MODE_BGR, 128, 64], [f.TRANSFORMED | f.FULL_FACE | f.MODE_BGR, 128, 64], [f.TRANSFORMED | f.FULL_FACE | f.MODE_M | f.MASK_FULL, 128, 64], [f.TRANSFORMED | f.FULL_FACE | f.MODE_BGR, 128] ], random_flip=True ),
                    TrainingDataGenerator(TrainingDataType.FACE, self.training_data_dst_path, debug=self.is_debug(), batch_size=self.batch_size, output_sample_types=[ [f.WARPED_TRANSFORMED | f.FULL_FACE | f.MODE_BGR, 128, 64], [f.TRANSFORMED | f.FULL_FACE | f.MODE_BGR, 128, 64], [f.TRANSFORMED | f.FULL_FACE | f.MODE_M | f.MASK_FULL, 128, 64], [f.TRANSFORMED | f.FULL_FACE | f.MODE_BGR, 128] ], random_flip=True )
                ])
                
    #override
    def onSave(self):        
        self.save_weights_safe( [[self.encoder, self.get_strpath_storage_for_file(self.encoderH5)],
                                [self.decoder_src, self.get_strpath_storage_for_file(self.decoder_srcH5)],
                                [self.decoder_dst, self.get_strpath_storage_for_file(self.decoder_dstH5)]] )
        
    #override
    def onTrainOneEpoch(self, sample):
        warped_src, target_src, target_src_full_mask, _ = sample[0]
        warped_dst, target_dst, target_dst_full_mask, _ = sample[1]    

     
        total, loss_src_bgr, loss_src_mask, loss_dst_bgr, loss_dst_mask = self.ae.train_on_batch( [warped_src, target_src_full_mask, warped_dst, target_dst_full_mask], [target_src, target_src_full_mask, target_dst, target_dst_full_mask] )

        return ( ('loss_src', loss_src_bgr), ('loss_dst', loss_dst_bgr) )
    
    
    def unslice(self, t):
        ch = t[0][0].shape[3]
    
        gw10 = np.repeat ( np.repeat ( np.reshape( np.linspace(1,0,32), (1,32,1) ) , (64,), 0 ), (ch,), -1 )
        gw01 = 1-gw10        
        
        l1 = np.concatenate ( [  t[0][0][:,:,0:32,:],        
                                 gw10*t[0][0][:,:,32:,:]+gw01*t[0][1][:,:,0:32,:],
                                 gw10*t[0][1][:,:,32:,:]+gw01*t[0][2][:,:,0:32,:],        
                                 t[0][2][:,:,32:,:]
                               ], axis=2)                           
                              
        l2 = np.concatenate ( [  t[1][0][:,:,0:32,:],        
                                 gw10*t[1][0][:,:,32:,:]+gw01*t[1][1][:,:,0:32,:],
                                 gw10*t[1][1][:,:,32:,:]+gw01*t[1][2][:,:,0:32,:],        
                                 t[1][2][:,:,32:,:]
                               ], axis=2)        
        
        l3 = np.concatenate ( [  t[2][0][:,:,0:32,:],        
                                 gw10*t[2][0][:,:,32:,:]+gw01*t[2][1][:,:,0:32,:],
                                 gw10*t[2][1][:,:,32:,:]+gw01*t[2][2][:,:,0:32,:],        
                                 t[2][2][:,:,32:,:]
                               ], axis=2)  
                               
        gh10 = np.repeat ( np.repeat ( np.reshape( np.linspace(1,0,32), (32,1,1) ) , (128,), 1 ), (ch,), -1 )
        gh01 = 1-gh10
        
        img = np.concatenate ( [ l1[:,0:32,:,:],        
                                 gh10*l1[:,32:,:,:]+gh01*l2[:,0:32,:,:],        
                                 gh10*l2[:,32:,:,:]+gh01*l3[:,0:32,:,:],        
                                 l3[:,32:,:,:] 
                               ], axis=1)   
        return img
        
    def src_view_from_128(self, in_t):
    
        in_t = [ [in_t[:,0:64,0:64,:], in_t[:,0:64,32:96,:], in_t[:,0:64,64:128,:]],
                 [in_t[:,32:96,0:64,:], in_t[:,32:96,32:96,:], in_t[:,32:96,64:128,:]],
                 [in_t[:,64:128,0:64,:], in_t[:,64:128,32:96,:], in_t[:,64:128,64:128,:]]
               ]
                    
        in_pr_t = [ [self.src_view([x]),self.src_view([y]),self.src_view([z])] for x,y,z in in_t ]
        
        t = [ [ x[0],y[0],z[0] ] for x,y,z in in_pr_t ]
        m = [ [ x[1],y[1],z[1] ] for x,y,z in in_pr_t ]

        return [self.unslice(t), self.unslice(m)]
        
    #override
    def onGetPreview(self, sample):
        test_A   = sample[0][1][0:4] #first 4 samples
        test_A_m = sample[0][2][0:4]
        test_A_t = sample[0][3][0:4]
        test_B   = sample[1][1][0:4]
        test_B_m = sample[1][2][0:4]
        test_B_t = sample[1][3][0:4]
        
        (AB_t, AB_m) = self.src_view_from_128 (test_B_t)
        
        AB_m = [ np.repeat(m, (3,),-1) for m in AB_m ]
        
        AA, mAA = self.src_view([test_A])                                       
        AB, mAB = self.src_view([test_B])
        BB, mBB = self.dst_view([test_B])
        
        mAA = np.repeat ( mAA, (3,), -1)
        mAB = np.repeat ( mAB, (3,), -1)
        mBB = np.repeat ( mBB, (3,), -1)
        
        st = np.concatenate ( (
                                  np.concatenate (
                                  (
                                  np.concatenate ( (test_A[0], AA[0], test_B[0], BB[0]), axis=1 ),
                                  np.concatenate ( (test_A[1], AA[1], test_B[1], BB[1]), axis=1 ),
                                  np.concatenate ( (test_A[2], AA[2], test_B[2], BB[2]), axis=1 ),
                                  np.concatenate ( (test_A[3], AA[3], test_B[3], BB[3]), axis=1 )
                                  )
                                  ,axis=0),
                                  
                                  np.concatenate ( (
                                                      np.concatenate ( (test_B_t[0], AB_t[0], AB_m[0]) , axis=1 ),
                                                      np.concatenate ( (test_B_t[1], AB_t[1], AB_m[1]) , axis=1 )
                                                    ), axis=0 ) 
                              ), axis=1 )
        return [ ('SUBF128', st ) ]
        #for i in range(0, len(test_A)):
        #    st.append ( np.concatenate ( (
        #        test_A[i,:,:,0:3],
        #        AA[i],
        #        mAA[i],
        #        test_B[i,:,:,0:3], 
        #        BB[i], 
        #        mBB[i],                
        #        AB[i],
        #        mAB[i]
        #        ), axis=1) )
            
        #return [ ('SUBF128', np.concatenate ( st, axis=0 ) ) ]


        
    def predictor_func (self, face):
        
        face_128_bgr = face[...,0:3]
        #face_128_mask = np.expand_dims(face[...,3],-1)
        #z = np.expand_dims(face_128_bgr,0)
        #print(z.shape)
        x, mx = self.src_view_from_128 ( np.expand_dims(face_128_bgr,0) )
        x, mx = x[0], mx[0]     
        
        return np.concatenate ( (x,mx), -1 )

    #override
    def get_converter(self, **in_options):
        from models import ConverterMasked
        
        if 'erode_mask_modifier' not in in_options.keys():
            in_options['erode_mask_modifier'] = 0
        in_options['erode_mask_modifier'] += 30
            
        if 'blur_mask_modifier' not in in_options.keys():
            in_options['blur_mask_modifier'] = 0
        in_options['blur_mask_modifier'] += 0
        
        return ConverterMasked(self.predictor_func, predictor_input_size=128, output_size=128, face_type=FaceType.FULL, **in_options)
        
    def Build(self, created_vram_gb):
        bgr_shape = (64, 64, 3)
        mask_shape = (64, 64, 1)
        
        def Encoder(input_shape):
            input_layer = self.keras.layers.Input(input_shape)
            x = input_layer
            if created_vram_gb >= 4:
                x = conv(self.keras, x, 128)
                x = conv(self.keras, x, 256)
                x = conv(self.keras, x, 512)
                x = conv(self.keras, x, 1024)
                x = self.keras.layers.Dense(1024)(self.keras.layers.Flatten()(x))
                x = self.keras.layers.Dense(4 * 4 * 1024)(x)
                x = self.keras.layers.Reshape((4, 4, 1024))(x)
                x = upscale(self.keras, x, 512)
            else:
                x = conv(self.keras, x, 128 )
                x = conv(self.keras, x, 256 )
                x = conv(self.keras, x, 512 )
                x = conv(self.keras, x, 768 )
                x = self.keras.layers.Dense(512)(self.keras.layers.Flatten()(x))
                x = self.keras.layers.Dense(4 * 4 * 512)(x)
                x = self.keras.layers.Reshape((4, 4, 512))(x)
                x = upscale(self.keras, x, 256)
                
            return self.keras.models.Model(input_layer, x)

        def Decoder():
            if created_vram_gb >= 4:    
                input_ = self.keras.layers.Input(shape=(8, 8, 512))
                x = input_
                x = upscale(self.keras, x, 512)
                x = upscale(self.keras, x, 256)
                x = upscale(self.keras, x, 128)

            else:
                input_ = self.keras.layers.Input(shape=(8, 8, 256))
                
                x = input_
                x = upscale(self.keras, x, 256)
                x = upscale(self.keras, x, 128)
                x = upscale(self.keras, x, 64)
                
            y = input_  #mask decoder
            y = upscale(self.keras, y, 256)
            y = upscale(self.keras, y, 128)
            y = upscale(self.keras, y, 64)
            
            x = self.keras.layers.convolutional.Conv2D(3, kernel_size=5, padding='same', activation='sigmoid')(x)
            y = self.keras.layers.convolutional.Conv2D(1, kernel_size=5, padding='same', activation='sigmoid')(y)
            
            
            return self.keras.models.Model(input_, [x,y])
            
        return bgr_shape, mask_shape, Encoder(bgr_shape), Decoder(), Decoder()
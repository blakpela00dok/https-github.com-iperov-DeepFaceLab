from models import ModelBase
from models import TrainingDataType
import numpy as np
import cv2

from nnlib import DSSIMMaskLossClass
from nnlib import conv
from nnlib import upscale
from nnlib import resize_like
from nnlib import total_variation_loss
from nnlib import PixelShufflerClass
from nnlib import tf_dssim
from facelib import FaceType

class Model(ModelBase):

    GAH5 = 'GA.h5'
    DAH5 = 'DA.h5'
    GBH5 = 'GB.h5'
    DBH5 = 'DB.h5'

    #override
    def onInitialize(self, batch_size=-1, **in_options):
        tf = self.tf
        K = self.keras.backend
        
        #if self.gpu_total_vram_gb < 4:
        #    raise Exception ('Sorry, this model works only on 4GB+ GPU')
        
        self.batch_size = batch_size
        if self.batch_size == 0:          
            if self.gpu_total_vram_gb == 4:
                self.batch_size = 2
            elif self.gpu_total_vram_gb == 5:
                self.batch_size = 4
            elif self.gpu_total_vram_gb == 6:
                self.batch_size = 8
            else: 
                self.batch_size = 16
    
        self.batch_size = 1
                        
        self.GA = self.Generator()
        self.DA = self.Discriminator()
        self.GB = self.Generator()
        self.DB = self.Discriminator()

        if not self.is_first_run():
            self.GA.load_weights (self.get_strpath_storage_for_file(self.GAH5))
            self.DA.load_weights (self.get_strpath_storage_for_file(self.DAH5))
            self.GB.load_weights (self.get_strpath_storage_for_file(self.GBH5))
            self.DB.load_weights (self.get_strpath_storage_for_file(self.DBH5))
            
        if self.is_training_mode:
            self.GA, self.DA, self.GB, self.DB = self.to_multi_gpu_model_if_possible ( [self.GA, self.DA, self.GB, self.DB] )
 
        real_A, gen_B, rec_A = self.GA.inputs[0], self.GA.outputs[0], self.GB(self.GA.outputs)
        real_B, gen_A, rec_B = self.GB.inputs[0], self.GB.outputs[0], self.GA(self.GB.outputs)
        
        real_A_DA = self.DA([real_A])
        gen_A_DA  = self.DA([gen_A])
        loss_DA = K.mean(K.square(real_A_DA - K.ones_like(real_A_DA))) + \
                  K.mean(K.square(gen_A_DA  - K.zeros_like(gen_A_DA)))        
        loss_GA = K.mean(K.square(gen_A_DA  - K.ones_like(gen_A_DA)))
        loss_GA_cyc = tf_dssim(tf, rec_A/2 + 0.5, real_A/2 + 0.5) + 10*K.mean(K.abs(rec_A - real_A))#
        
        real_B_DB = self.DB([real_B])
        gen_B_DB  = self.DB([gen_B])
        loss_DB = K.mean(K.square(real_B_DB - K.ones_like(real_B_DB))) + \
                  K.mean(K.square(gen_B_DB  - K.zeros_like(gen_B_DB)))
        loss_GB = K.mean(K.square(gen_B_DB  - K.ones_like(gen_B_DB)))
        loss_GB_cyc = tf_dssim(tf, rec_B/2 + 0.5, real_B/2 + 0.5) + 10*K.mean(K.abs(rec_B - real_B))#
        
        weights_D = self.DA.trainable_weights + self.DB.trainable_weights
        weights_G = self.GA.trainable_weights + self.GB.trainable_weights

        self.D_train = K.function ([real_A, real_B],[loss_DA, loss_DB],
                                self.keras.optimizers.Adam(lr=2e-4, beta_1=0.5, beta_2=0.999).get_updates(loss_DA+loss_DB, weights_D) )
        
        self.G_train = K.function ([real_A, real_B],[loss_GA, loss_GB, (loss_GA_cyc+loss_GB_cyc)],   
                                self.keras.optimizers.Adam(lr=2e-4, beta_1=0.5, beta_2=0.999).get_updates(loss_GA+loss_GB+(loss_GA_cyc+loss_GB_cyc), weights_G) )
        
        self.GA_view = K.function ([real_A],[gen_B,rec_A])
        self.GB_view = K.function ([real_B],[gen_A,rec_B])
        self.GA_convert = K.function ([real_A],[gen_B])
        
        if self.is_training_mode:
            from models import TrainingDataGenerator
            f = TrainingDataGenerator.SampleTypeFlags 
            self.set_training_data_generators ([            
                    TrainingDataGenerator(TrainingDataType.FACE, self.training_data_src_path, debug=self.is_debug(), normalize_tanh=True, batch_size=self.batch_size, output_sample_types=[ [f.TRANSFORMED | f.HEAD_FACE | f.MODE_BGR, 256], [f.SOURCE | f.HEAD_FACE | f.MODE_BGR, 256] ] ),
                    TrainingDataGenerator(TrainingDataType.FACE, self.training_data_dst_path, debug=self.is_debug(), normalize_tanh=True, batch_size=self.batch_size, output_sample_types=[ [f.TRANSFORMED | f.HEAD_FACE | f.MODE_BGR, 256], [f.SOURCE | f.HEAD_FACE | f.MODE_BGR, 256] ] ),
                   ])
                
        self.supress_std_once = False
        
    #override
    def onSave(self):        
        self.save_weights_safe( [[self.GA,    self.get_strpath_storage_for_file(self.GAH5)],
                                 [self.GB,    self.get_strpath_storage_for_file(self.GBH5)],
                                 [self.DA,    self.get_strpath_storage_for_file(self.DAH5)],
                                 [self.DB,    self.get_strpath_storage_for_file(self.DBH5)] ] )
        

        
        
    #override
    def onTrainOneEpoch(self, sample):
        target_src, source_src = sample[0]
        target_dst, source_dst = sample[1]    

        loss_DA, loss_DB           = self.D_train ([target_src, target_dst])
        loss_GA, loss_GB, loss_CYC = self.G_train ([target_src, target_dst])
        
        return ( ('DA', loss_DA), ('DB', loss_DB), ('GA', loss_GA), ('GB', loss_GB), ('CYC', loss_CYC) )
        

    #override
    def onGetPreview(self, sample):
        test_A   = sample[0][1][0:1] #first 1 samples
        test_B   = sample[1][1][0:1] #first 1 samples
        
        B, rA = self.GA_view([test_A])
        A, rB = self.GB_view([test_B])

        test_A = test_A / 2 + 0.5
        test_B = test_B / 2 + 0.5
        
        B = B / 2 + 0.5
        rA = rA / 2 + 0.5
        
        A = A / 2 + 0.5
        rB = rB / 2 + 0.5
        
        r = np.concatenate ( (np.concatenate ( (test_A[0], B[0], rA[0]), axis=1),
                              np.concatenate ( (test_B[0], A[0], rB[0]), axis=1)
                            ), axis=0)
                
        return [ ('ABA, BAB', r ) ]
    
    def predictor_func (self, face):
        x = self.GA_convert ( [ np.expand_dims(face *2 - 1,0)]  )[0]
        return x[0] / 2 + 0.5
        
    #override
    def get_converter(self, **in_options):
        from models import ConverterAvatar
                   
        return ConverterAvatar.ConverterAvatar(self.predictor_func, predictor_input_size=256, output_size=256, **in_options)
        
    def Generator(self):
        def conv2d(layer_input, filters, f_size=4):
            x = self.keras.layers.convolutional.Conv2D(filters, kernel_size=f_size, strides=2, padding='same')(layer_input)
            x = self.keras.layers.advanced_activations.LeakyReLU(alpha=0.2)(x)
            x = self.keras_contrib.layers.normalization.InstanceNormalization()(x)
            return x

        def deconv2d(layer_input, skip_input, filters, k_size=4):
            x = layer_input
            #x = self.keras.layers.convolutional.Conv2D(filters*4, kernel_size=k_size, strides=1, kernel_initializer=self.keras.initializers.RandomNormal(0, 0.02), padding='same')(x)
            #x = self.keras.layers.advanced_activations.LeakyReLU(alpha=0.2)(x)
            #x = PixelShufflerClass(self.keras)()(x)
       
            x = self.keras.layers.UpSampling2D()(x)
            x = self.keras.layers.convolutional.Conv2D(filters, kernel_size=k_size, strides=1, kernel_initializer=self.keras.initializers.RandomNormal(0, 0.02), padding='same', activation='relu')(x)
            x = self.keras_contrib.layers.normalization.InstanceNormalization()(x)
            x = self.keras.layers.Concatenate()([x, skip_input])
            return x

        # Image input
        d0 = self.keras.layers.Input ( shape=(256,256,3) )

        n = 90
        # Downsampling
        d1 = conv2d(d0, n)
        d2 = conv2d(d1, n*2)
        d3 = conv2d(d2, n*4)
        d4 = conv2d(d3, n*8)
        d5 = conv2d(d4, n*16)
        u5 = d5
        # Upsampling
        u5 = deconv2d(u5, d4, n*8)
        u4 = deconv2d(u5, d3, n*4)
        u3 = deconv2d(u4, d2, n*2)
        u2 = deconv2d(u3, d1, n)

        #u1 = self.keras.layers.convolutional.Conv2D(64, kernel_size=3, strides=1, kernel_initializer=self.keras.initializers.RandomNormal(0, 0.02), padding='same')(u2)
        #u1 = self.keras.layers.advanced_activations.LeakyReLU(alpha=0.2)(u1)
        #u1 = self.keras.layers.convolutional.Conv2DTranspose(64, kernel_size=4, strides=2, kernel_initializer=self.keras.initializers.RandomNormal(0, 0.02), padding='same' )(u1)
        #u1 = PixelShufflerClass(self.keras)()(u1)
        u1 = self.keras.layers.UpSampling2D()(u2)
            
        output_img = self.keras.layers.convolutional.Conv2D(3, kernel_size=4, strides=1, kernel_initializer=self.keras.initializers.RandomNormal(0, 0.02), padding='same', 
                                            activation='tanh')(u1)

        return self.keras.models.Model(d0, output_img)
        
    def Discriminator(self):

        def d_layer(layer_input, filters, f_size=4, normalization=True):
            x = self.keras.layers.convolutional.Conv2D(filters, kernel_size=f_size, strides=2, padding='same')(layer_input)
            x = self.keras.layers.advanced_activations.LeakyReLU(alpha=0.2)(x)
            if normalization:
                x = self.keras_contrib.layers.normalization.InstanceNormalization()(x)
                #x = self.keras.layers.BatchNormalization()(x)
            return x

        d0 = self.keras.layers.Input ( shape=(256,256,3) )

        n = 90
        d1 = d_layer(d0, n, normalization=False)
        d2 = d_layer(d1, n*2)
        d3 = d_layer(d2, n*4)
        d4 = d_layer(d3, n*8)
        d5 = d_layer(d4, n*16)

        validity = self.keras.layers.convolutional.Conv2D(1, kernel_size=5, strides=1, padding='same')(d5)

        return self.keras.models.Model(d0, validity)    
   